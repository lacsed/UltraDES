﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace medidorPerformance
{
    class Program
    {
        static void Main(string[] args)
        {
            Process proc = Process.GetCurrentProcess();
            List<double> memory = new List<double>();
            List<double> times = new List<double>();
            var timer = new Stopwatch();

            //proc = Process.Start("D:\\UltraDES-master_backup\\Test - Monolitic Supervisor\\bin\\Release\\Test - Monolitic Supervisor.exe");
            //proc = Process.Start("D:\\UltraDES\\Test - Monolitic Supervisor\\bin\\Release\\Test - Monolitic Supervisor.exe");
            proc = Process.Start("D:\\UltraDES\\Test - Modular Supervisor\\bin\\Release\\Test.exe");
            //proc = Process.Start("D:\\UltraDES-master_backup\\Test - Modular Supervisor\\bin\\Release\\Test.exe");
            timer.Start();
            do
            {
                if (proc.HasExited)
                    break;
                proc.Refresh();
                long memsize = proc.WorkingSet64;
                memory.Add(memsize / (1024.0 * 1024.0));
                times.Add(timer.ElapsedMilliseconds / 1000.0);

            } while (!proc.WaitForExit(30));

            Console.WriteLine("Tempo: {0}", proc.UserProcessorTime.TotalSeconds);

            var arq = new StreamWriter("memoria_nova_fsm.txt");
            
            for(int i = 0; i < times.Count; i++)
            {
                if(i == 0)
                    arq.Write("[{0},{1}]", times.ElementAt(i), memory.ElementAt(i));
                else
                    arq.Write(", [{0},{1}]", times.ElementAt(i), memory.ElementAt(i));
                i++;
            }

            arq.Close();
            //Console.ReadLine();
        }
    }
}
