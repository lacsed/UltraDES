﻿/*****************************************************************************************
 *   UltraDES is an open source library for modeling, analisys and control of Discrete 
 *   Event Systems,it has been developed at LACSED|UFMG (http://www.lacsed.eng.ufmg.br)
 *   More informations and download at https://github.com/lucasvra/UltraDES
 *****************************************************************************************/

using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using UltraDES;

namespace Monolithic
{
    internal class Program
    {
        private static void ClusterTool(int clusters, out List<DeterministicFiniteAutomaton> plants, out List<DeterministicFiniteAutomaton> specs)
        {
            var s = Enumerable.Range(0, 4).Select(
                k => new State(k.ToString(),
                    k == 0
                        ? Marking.Marked
                        : Marking.Unmarked))
                .ToArray();

            plants = new List<DeterministicFiniteAutomaton>();
            specs = new List<DeterministicFiniteAutomaton>();

            int max = clusters;

            var evs = Enumerable.Range(1, max).SelectMany(i => Enumerable.Range(0, 9).Select(
                k => new Event(String.Format("{0}|{1}", i, k),
                    k % 2 == 0
                        ? Controllability.Uncontrollable
                        : Controllability.Controllable))).ToList();

            for (int i = 1; i <= max; i++)
            {
                var e = Enumerable.Range(0, 9).Select(
                    k => new Event(String.Format("{0}|{1}", i, k),
                        k % 2 == 0
                            ? Controllability.Uncontrollable
                            : Controllability.Controllable))
                    .ToArray();

                var Ri = new DeterministicFiniteAutomaton(
                    i != max
                        ? new[]
                        {
                            new Transition(s[0], e[1], s[1]),
                            new Transition(s[1], e[2], s[0]),
                            new Transition(s[0], e[3], s[2]),
                            new Transition(s[2], e[4], s[0]),
                            new Transition(s[0], e[5], s[3]),
                            new Transition(s[3], e[6], s[0])
                        }
                        : new[]
                        {
                            new Transition(s[0], e[1], s[1]),
                            new Transition(s[1], e[2], s[0]),
                            new Transition(s[0], e[5], s[2]),
                            new Transition(s[2], e[4], s[0]),
                        },
                        s[0], String.Format("R{0}", i));

                var Ci = new DeterministicFiniteAutomaton(new[]
                {
                    new Transition(s[0], e[7], s[1]),
                    new Transition(s[1], e[8], s[0]),
                },
                s[0], String.Format("C{0}", i));

                var Ei = new DeterministicFiniteAutomaton(new[]
                {
                    new Transition(s[0], e[2], s[1]),
                    new Transition(s[1], e[7], s[0]),
                    new Transition(s[0], e[8], s[2]),
                    new Transition(s[2], e[5], s[0])
                },
                s[0], String.Format("E{0}", i));

                plants.Add(Ri);
                plants.Add(Ci);
                specs.Add(Ei);
            }

            for (int i = 1; i < max; i++)
            {
                var e61 = new Event(String.Format("{0}|6", i),
                    Controllability.Uncontrollable);
                var e31 = new Event(String.Format("{0}|3", i),
                    Controllability.Controllable);
                var e12 = new Event(String.Format("{0}|1", i + 1),
                    Controllability.Controllable);
                var e42 = new Event(String.Format("{0}|4", i + 1),
                    Controllability.Uncontrollable);

                var Eij = new DeterministicFiniteAutomaton(new[]
                {
                    new Transition(s[0], e61, s[1]),
                    new Transition(s[1], e12, s[0]),
                    new Transition(s[0], e42, s[2]),
                    new Transition(s[2], e31, s[0])
                },
                s[0], String.Format("E{0}_{1}", i, i + 1));

                specs.Add(Eij);
            }
        }

        private static DeterministicFiniteAutomaton Carol()
        {
            var a5 = new State("5A", Marking.Marked);
            var a6 = new State("6A", Marking.Marked);
            var a7 = new State("7A", Marking.Marked);
            var a8 = new State("8A", Marking.Marked);

            var a1f = new Event("a1f", Controllability.Uncontrollable);
            var a2f = new Event("a2f", Controllability.Uncontrollable);
            var a3f = new Event("a3f", Controllability.Uncontrollable);
            var a4f = new Event("a4f", Controllability.Uncontrollable);
            var a5f = new Event("a5f", Controllability.Uncontrollable); // acrescentando tarefas
            var a6f = new Event("a6f", Controllability.Uncontrollable); // acrescentando tarefas
            var a7f = new Event("a7f", Controllability.Uncontrollable); // acrescentando tarefas
            var a8f = new Event("a8f", Controllability.Uncontrollable); // acrescentando tarefas
            var a9f = new Event("a9f", Controllability.Uncontrollable); // acrescentando tarefas
            var a10f = new Event("a10f", Controllability.Uncontrollable); // acrescentando tarefas


            var a5e = new Event("a5e", Controllability.Controllable);
            var a6e = new Event("a6e", Controllability.Controllable);
            var a7e = new Event("a7e", Controllability.Controllable);
            var a8e = new Event("a8e", Controllability.Controllable);

            var T1 = new HashSet<Transition>
            {
                new Transition (a6,a7e,a7),
                new Transition (a7,a6e,a6),
                new Transition (a8,a3f,a8), // tarefa 3 na região 8
                new Transition (a6,a4f,a6), // tarefa 4 na região 6
                new Transition (a6,a2f,a6), // tarefa 2 na região 6
                new Transition (a6,a5e,a5),
                new Transition (a5,a6e,a6),
                new Transition (a7,a1f,a7), // tarefa 1 na região 7
                new Transition (a5,a8e,a8),
                new Transition (a8,a5e,a5),
                new Transition (a8,a7e,a7),
                new Transition (a7,a8e,a8),
                new Transition (a8,a8f,a8), // tarefa 8 na região 8
                new Transition (a7,a5f,a7), // tarefa 5 na região 7
                new Transition (a8,a7f,a8), // tarefa 7 na região 8
                new Transition (a6,a6f,a6), // tarefa 6 na região 6
                new Transition (a6,a9f,a6), // tarefa 9 na região 6
                new Transition (a7,a10f,a7) // tarefa 10 na região 7

            };


            var GeoA = new DeterministicFiniteAutomaton(T1, a5, "GeoA");
            //GeoA.ShowAutomaton("GeoA");

            var s0 = new State("I", Marking.Marked);
            var s1 = new State("1S", Marking.Marked);
            var s2 = new State("2S", Marking.Marked);
            var s3 = new State("3S", Marking.Marked);
            var s4 = new State("4S", Marking.Marked);
            var s5 = new State("5S", Marking.Marked);
            var s6 = new State("6S", Marking.Marked);
            var s7 = new State("7S", Marking.Marked);
            var s8 = new State("8S", Marking.Marked);
            var s9 = new State("9S", Marking.Marked);
            var s10 = new State("10S", Marking.Marked);

            var a1s = new Event("a1s", Controllability.Controllable);
            var a2s = new Event("a2s", Controllability.Controllable);
            var a3s = new Event("a3s", Controllability.Controllable);
            var a4s = new Event("a4s", Controllability.Controllable);
            var a5s = new Event("a5s", Controllability.Controllable); // acrescentando tarefas
            var a6s = new Event("a6s", Controllability.Controllable); // acrescentando tarefas
            var a7s = new Event("a7s", Controllability.Controllable); // acrescentando tarefas
            var a8s = new Event("a8s", Controllability.Controllable); // acrescentando tarefas
            var a9s = new Event("a9s", Controllability.Controllable); // acrescentando tarefas
            var a10s = new Event("a10s", Controllability.Controllable); // acrescentando tarefas



            var T2 = new HashSet<Transition>
            {
                //new Transition (s0,a5e,s0), // teste mudança
                //new Transition (s0,a6e,s0), // teste
                //new Transition (s0,a7e,s0), // teste
                //new Transition (s0,a8e,s0), // teste
                new Transition (s0,a1s,s1),
                new Transition (s1,a1f,s0),
                new Transition (s0,a2s,s2),
                new Transition (s2,a2f,s0),
                new Transition (s0,a3s,s3),
                new Transition (s3,a3f,s0),
                new Transition (s0,a4s,s4),
                new Transition (s4,a4f,s0),
                new Transition (s1,a5e,s1),
                new Transition (s1,a6e,s1),
                new Transition (s1,a7e,s1),
                new Transition (s1,a8e,s1),
                new Transition (s2,a5e,s2),
                new Transition (s2,a6e,s2),
                new Transition (s2,a7e,s2),
                new Transition (s2,a8e,s2),
                new Transition (s3,a5e,s3),
                new Transition (s3,a6e,s3),
                new Transition (s3,a7e,s3),
                new Transition (s3,a8e,s3),
                new Transition (s4,a5e,s4),
                new Transition (s4,a6e,s4),
                new Transition (s4,a7e,s4),
                new Transition (s4,a8e,s4),

                // acrescentando as tarefas 5, 6, 7, 8, 9 ,10
                new Transition (s0,a5s,s5),
                new Transition (s5,a5f,s0),
                new Transition (s0,a6s,s6),
                new Transition (s6,a6f,s0),
                new Transition (s0,a7s,s7),
                new Transition (s7,a7f,s0),
                new Transition (s0,a8s,s8),
                new Transition (s8,a8f,s0),
                new Transition (s0,a9s,s9),
                new Transition (s9,a9f,s0),
                new Transition (s0,a10s,s10),
                new Transition (s10,a10f,s0),
                new Transition (s5,a5e,s5),
                new Transition (s5,a6e,s5),
                new Transition (s5,a7e,s5),
                new Transition (s5,a8e,s5),
                new Transition (s6,a5e,s6),
                new Transition (s6,a6e,s6),
                new Transition (s6,a7e,s6),
                new Transition (s6,a8e,s6),
                new Transition (s7,a5e,s7),
                new Transition (s7,a6e,s7),
                new Transition (s7,a7e,s7),
                new Transition (s7,a8e,s7),
                new Transition (s8,a5e,s8),
                new Transition (s8,a6e,s8),
                new Transition (s8,a7e,s8),
                new Transition (s8,a8e,s8),
                new Transition (s9,a5e,s9),
                new Transition (s9,a6e,s9),
                new Transition (s9,a7e,s9),
                new Transition (s9,a8e,s9),
                new Transition (s10,a5e,s10),
                new Transition (s10,a6e,s10),
                new Transition (s10,a7e,s10),
                new Transition (s10,a8e,s10)
            };

            var TaskA = new DeterministicFiniteAutomaton(T2, s0, "TaskA");
            //TaskA.ShowAutomaton("TaskA");

            // Robo B

            var b5 = new State("5B", Marking.Marked);
            var b6 = new State("6B", Marking.Marked);
            var b7 = new State("7B", Marking.Marked);
            var b8 = new State("8B", Marking.Marked);

            var b1f = new Event("b1f", Controllability.Uncontrollable);
            var b2f = new Event("b2f", Controllability.Uncontrollable);
            var b3f = new Event("b3f", Controllability.Uncontrollable);
            var b4f = new Event("b4f", Controllability.Uncontrollable);
            var b5f = new Event("b5f", Controllability.Uncontrollable); // acrescentando tarefas
            var b6f = new Event("b6f", Controllability.Uncontrollable); // acrescentando tarefas
            var b7f = new Event("b7f", Controllability.Uncontrollable); // acrescentando tarefas
            var b8f = new Event("b8f", Controllability.Uncontrollable); // acrescentando tarefas
            var b9f = new Event("b9f", Controllability.Uncontrollable); // acrescentando tarefas
            var b10f = new Event("b10f", Controllability.Uncontrollable); // acrescentando tarefas

            var b5e = new Event("b5e", Controllability.Controllable);
            var b6e = new Event("b6e", Controllability.Controllable);
            var b7e = new Event("b7e", Controllability.Controllable);
            var b8e = new Event("b8e", Controllability.Controllable);

            var T3 = new HashSet<Transition>
            {
                new Transition (b6,b7e,b7),
                new Transition (b7,b6e,b6),
                new Transition (b8,b3f,b8), // tarefa 3 na região 8
                new Transition (b6,b4f,b6), // tarefa 4 na região 6
                new Transition (b6,b2f,b6), // tarefa 2 na região 6
                new Transition (b6,b5e,b5),
                new Transition (b5,b6e,b6),
                new Transition (b7,b1f,b7), // tarefa 1 na região 7
                new Transition (b5,b8e,b8),
                new Transition (b8,b5e,b5),
                new Transition (b8,b7e,b7),
                new Transition (b7,b8e,b8),
                new Transition (b8,b8f,b8), // tarefa 8 na região 8
                new Transition (b7,b5f,b7), // tarefa 5 na região 7
                new Transition (b8,b7f,b8), // tarefa 7 na região 8
                new Transition (b6,b6f,b6), // tarefa 6 na região 6
                new Transition (b6,b9f,b6), // tarefa 9 na região 6
                new Transition (b7,b10f,b7) // tarefa 10 na região 7

            };


            var GeoB = new DeterministicFiniteAutomaton(T3, b8, "GeoB");
            //GeoB.ShowAutomaton("GeoB");


            var bs0 = new State("I", Marking.Marked);
            var bs1 = new State("1S", Marking.Marked);
            var bs2 = new State("2S", Marking.Marked);
            var bs3 = new State("3S", Marking.Marked);
            var bs4 = new State("4S", Marking.Marked);
            var bs5 = new State("5S", Marking.Marked);
            var bs6 = new State("6S", Marking.Marked);
            var bs7 = new State("7S", Marking.Marked);
            var bs8 = new State("8S", Marking.Marked);
            var bs9 = new State("9S", Marking.Marked);
            var bs10 = new State("10S", Marking.Marked);

            var b1s = new Event("b1s", Controllability.Controllable);
            var b2s = new Event("b2s", Controllability.Controllable);
            var b3s = new Event("b3s", Controllability.Controllable);
            var b4s = new Event("b4s", Controllability.Controllable);
            var b5s = new Event("b5s", Controllability.Controllable); // acrescentando tarefas
            var b6s = new Event("b6s", Controllability.Controllable); // acrescentando tarefas
            var b7s = new Event("b7s", Controllability.Controllable); // acrescentando tarefas
            var b8s = new Event("b8s", Controllability.Controllable); // acrescentando tarefas
            var b9s = new Event("b9s", Controllability.Controllable); // acrescentando tarefas
            var b10s = new Event("b10s", Controllability.Controllable); // acrescentando tarefas

            var T4 = new HashSet<Transition>
            {
                //new Transition (bs0,b5e,bs0), // teste mudança
                //new Transition (bs0,b6e,bs0), // teste
                //new Transition (bs0,b7e,bs0), // teste
                //new Transition (bs0,b8e,bs0), // teste
                new Transition (bs0,b1s,bs1),
                new Transition (bs1,b1f,bs0),
                new Transition (bs0,b2s,bs2),
                new Transition (bs2,b2f,bs0),
                new Transition (bs0,b3s,bs3),
                new Transition (bs3,b3f,bs0),
                new Transition (bs0,b4s,bs4),
                new Transition (bs4,b4f,bs0),
                new Transition (bs1,b5e,bs1),
                new Transition (bs1,b6e,bs1),
                new Transition (bs1,b7e,bs1),
                new Transition (bs1,b8e,bs1),
                new Transition (bs2,b5e,bs2),
                new Transition (bs2,b6e,bs2),
                new Transition (bs2,b7e,bs2),
                new Transition (bs2,b8e,bs2),
                new Transition (bs3,b5e,bs3),
                new Transition (bs3,b6e,bs3),
                new Transition (bs3,b7e,bs3),
                new Transition (bs3,b8e,bs3),
                new Transition (bs4,b5e,bs4),
                new Transition (bs4,b6e,bs4),
                new Transition (bs4,b7e,bs4),
                new Transition (bs4,b8e,bs4),

                // acrescentando as tarefas 5, 6, 7, 8, 9 e 10
                new Transition (bs0,b5s,bs5),
                new Transition (bs5,b5f,bs0),
                new Transition (bs0,b6s,bs6),
                new Transition (bs6,b6f,bs0),
                new Transition (bs0,b7s,bs7),
                new Transition (bs7,b7f,bs0),
                new Transition (bs0,b8s,bs8),
                new Transition (bs8,b8f,bs0),
                new Transition (bs0,b9s,bs9),
                new Transition (bs9,b9f,bs0),
                new Transition (bs0,b10s,bs10),
                new Transition (bs10,b10f,bs0),
                new Transition (bs5,b5e,bs5),
                new Transition (bs5,b6e,bs5),
                new Transition (bs5,b7e,bs5),
                new Transition (bs5,b8e,bs5),
                new Transition (bs6,b5e,bs6),
                new Transition (bs6,b6e,bs6),
                new Transition (bs6,b7e,bs6),
                new Transition (bs6,b8e,bs6),
                new Transition (bs7,b5e,bs7),
                new Transition (bs7,b6e,bs7),
                new Transition (bs7,b7e,bs7),
                new Transition (bs7,b8e,bs7),
                new Transition (bs8,b5e,bs8),
                new Transition (bs8,b6e,bs8),
                new Transition (bs8,b7e,bs8),
                new Transition (bs8,b8e,bs8),
                new Transition (bs9,b5e,bs9),
                new Transition (bs9,b6e,bs9),
                new Transition (bs9,b7e,bs9),
                new Transition (bs9,b8e,bs9),
                new Transition (bs10,b5e,bs10),
                new Transition (bs10,b6e,bs10),
                new Transition (bs10,b7e,bs10),
                new Transition (bs10,b8e,bs10)
            };

            var TaskB = new DeterministicFiniteAutomaton(T4, bs0, "TaskB");
            //TaskB.ShowAutomaton("TaskB");


            // Especificação 1
            //(Tarefa 1 deve preceder Tarefa 2 e deverá ser feito pelo mesmo robô)

            var N1 = new State("N", Marking.Unmarked);
            var f1 = new State("f1", Marking.Unmarked);
            var ff1 = new State("f1'", Marking.Unmarked);
            var f1f2 = new State("1f.2f", Marking.Marked);

            var h1 = new HashSet<Transition>
            {
                new Transition(N1, a1s, N1),
                new Transition(N1, b1s, N1),
                new Transition(N1, a1f, f1),
                new Transition(N1, b1f, ff1),
                new Transition(f1, a2s, f1),
                new Transition(ff1, b2s, ff1),
                new Transition(f1, a2f, f1f2),
                new Transition(ff1, b2f, f1f2)
            };

            var E1 = new DeterministicFiniteAutomaton(h1, N1, "E1");
            //E1.ShowAutomaton("E1");

            // Especificação 2
            //(Tarefa 3 deve preceder Tarefa 4 e deverá ser feito pelo mesmo robô)

            var N2 = new State("N", Marking.Unmarked);
            var f3 = new State("f3", Marking.Unmarked);
            var ff3 = new State("f3'", Marking.Unmarked);
            var f3f4 = new State("3f.4f", Marking.Marked);

            var h2 = new HashSet<Transition>
            {
                new Transition(N2, a3s, N2),
                new Transition(N2, b3s, N2),
                new Transition(N2, a3f, f3),
                new Transition(N2, b3f, ff3),
                new Transition(f3, a4s, f3),
                new Transition(ff3, b4s, ff3),
                new Transition(f3, a4f, f3f4),
                new Transition(ff3, b4f, f3f4)
            };

            var E2 = new DeterministicFiniteAutomaton(h2, N2, "E2");
            //E2.ShowAutomaton("E2");

            // Especificação 3
            //(No máximo um Robô deve estar na região 5)

            var N3 = new State("N5", Marking.Marked);
            var xa5 = new State("5A", Marking.Marked);
            var xb5 = new State("5B", Marking.Marked);

            var h3 = new HashSet<Transition>
            {
                new Transition(N3, a5e, xa5),
                new Transition(N3, b5e, xb5),
                new Transition(xa5, a6e, N3),
                //new Transition(xa5, a7e, N3),  // não é permitido passar da região 5 para a 7 (diagonal)
                new Transition(xa5, a8e, N3),
                new Transition(xb5, b6e, N3),
                //new Transition(xb5, b7e, N3),  // não é permitido passar da região 5 para a 7 (diagonal)
                new Transition(xb5, b8e, N3),
                //new Transition(xa5, a5e, xa5), // não tem necessidade (autolaço desnecessário)
                new Transition(xa5, b6e, xa5),
                new Transition(xa5, b7e, xa5),
                new Transition(xa5, b8e, xa5),
                // new Transition(xb5, b5e, xb5), // não tem necessidade (autolaço desnecessário)
                new Transition(xb5, a6e, xb5),
                new Transition(xb5, a7e, xb5),
                new Transition(xb5, a8e, xb5),
                new Transition(N3, a6e, N3),
                new Transition(N3, a7e, N3),
                new Transition(N3, a8e, N3),
                new Transition(N3, b6e, N3),
                new Transition(N3, b7e, N3),
                new Transition(N3, b8e, N3),
            };

            var E3 = new DeterministicFiniteAutomaton(h3, xa5, "E3");
            //E3.ShowAutomaton("E3");

            // Especificação 4
            //(No máximo um Robô deve estar na região 6)

            var N4 = new State("N6", Marking.Marked);
            var xa6 = new State("6A", Marking.Marked);
            var xb6 = new State("6B", Marking.Marked);

            var h4 = new HashSet<Transition>
            {
                new Transition(N4, a6e, xa6),
                new Transition(N4, b6e, xb6),
                new Transition(xa6, a5e, N4),
                new Transition(xa6, a7e, N4),
                //new Transition(xa6, a8e, N4), // não é permitido passar da região 6 para a 8 (diagonal)
                new Transition(xb6, b5e, N4),
                new Transition(xb6, b7e, N4),
                //new Transition(xb6, b8e, N4), // não é permitido passar da região 6 para a 8 (diagonal)
                // new Transition(xa6, a6e, xa6), // não tem necessidade (autolaço desnecessário)
                new Transition(xa6, b5e, xa6),
                new Transition(xa6, b7e, xa6),
                new Transition(xa6, b8e, xa6),
                // new Transition(xb6, b6e, xb6), // não tem necessidade (autolaço desnecessário)
                new Transition(xb6, a5e, xb6),
                new Transition(xb6, a7e, xb6),
                new Transition(xb6, a8e, xb6),
                new Transition(N4, a5e, N4),
                new Transition(N4, a7e, N4),
                new Transition(N4, a8e, N4),
                new Transition(N4, b5e, N4),
                new Transition(N4, b7e, N4),
                new Transition(N4, b8e, N4),
            };

            var E4 = new DeterministicFiniteAutomaton(h4, N4, "E4");
            //E4.ShowAutomaton("E4");

            // Especificação 5
            //(No máximo um Robô deve estar na região 7)

            var N5 = new State("N7", Marking.Marked);
            var xa7 = new State("7A", Marking.Marked);
            var xb7 = new State("7B", Marking.Marked);

            var h5 = new HashSet<Transition>
            {
                new Transition(N5, a7e, xa7),
                new Transition(N5, b7e, xb7),
                // new Transition(xa7, a5e, N5), // não é permitido passar da região 7 para a 5 (diagonal)
                new Transition(xa7, a6e, N5),
                new Transition(xa7, a8e, N5),
                //new Transition(xb7, b5e, N5), // não é permitido passar da região 7 para a 5 (diagonal)
                new Transition(xb7, b6e, N5),
                new Transition(xb7, b8e, N5),
                // new Transition(xa7, a7e, xa7), // não tem necessidade (autolaço desnecessário)
                new Transition(xa7, b5e, xa7),
                new Transition(xa7, b6e, xa7),
                new Transition(xa7, b8e, xa7),
                // new Transition(xb7, b7e, xb7), // não tem necessidade (autolaço desnecessário)
                new Transition(xb7, a5e, xb7),
                new Transition(xb7, a6e, xb7),
                new Transition(xb7, a8e, xb7),
                new Transition(N5, a6e, N5),
                new Transition(N5, a5e, N5),
                new Transition(N5, a8e, N5),
                new Transition(N5, b6e, N5),
                new Transition(N5, b5e, N5),
                new Transition(N5, b8e, N5),
            };

            var E5 = new DeterministicFiniteAutomaton(h5, N5, "E5");
            //E5.ShowAutomaton("E5");

            // Especificação 6
            //(No máximo um Robô deve estar na região 8)

            var N6 = new State("N8", Marking.Marked);
            var xa8 = new State("8A", Marking.Marked);
            var xb8 = new State("8B", Marking.Marked);

            var h6 = new HashSet<Transition>
            {
                new Transition(N6, a8e, xa8),
                new Transition(N6, b8e, xb8),
                new Transition(xa8, a5e, N6),
                //new Transition(xa8, a6e, N6), // não é permitido passar da região 8 para a 6 (diagonal)
                new Transition(xa8, a7e, N6),
                new Transition(xb8, b5e, N6),
                //new Transition(xb8, b6e, N6), // não é permitido passar da região 8 para a 6 (diagonal)
                new Transition(xb8, b7e, N6),
                new Transition(xa8, b5e, xa8),
                new Transition(xa8, b6e, xa8),
                new Transition(xa8, b7e, xa8),
               // new Transition(xa8, a8e, xa8), // não tem necessidade (autolaço desnecessário)
                new Transition(xb8, a5e, xb8),
                new Transition(xb8, a6e, xb8),
                new Transition(xb8, a7e, xb8),
                // new Transition(xb8, b8e, xb8), // não tem necessidade (autolaço desnecessário)
                new Transition(N6, a6e, N6),
                new Transition(N6, a7e, N6),
                new Transition(N6, a5e, N6),
                new Transition(N6, b6e, N6),
                new Transition(N6, b7e, N6),
                new Transition(N6, b5e, N6),
            };

            var E6 = new DeterministicFiniteAutomaton(h6, xb8, "E6");
            //E6.ShowAutomaton("E6");

            // Especificação 7
            //(Tarefa 5 deve preceder Tarefa 6 e deverá ser feito pelo mesmo robô)

            var N7 = new State("N", Marking.Unmarked);
            var f5 = new State("f5", Marking.Unmarked);
            var ff5 = new State("f5'", Marking.Unmarked);
            var f5f6 = new State("5f.6f", Marking.Marked);

            var h7 = new HashSet<Transition>
            {
                new Transition(N7, a5s, N7),
                new Transition(N7, b5s, N7),
                new Transition(N7, a5f, f5),
                new Transition(N7, b5f, ff5),
                new Transition(f5, a6s, f5),
                new Transition(ff5, b6s, ff5),
                new Transition(f5, a6f, f5f6),
                new Transition(ff5, b6f, f5f6)
            };

            var E7 = new DeterministicFiniteAutomaton(h7, N7, "E7");
            //E7.ShowAutomaton("E7");

            // Especificação 8
            //(Tarefa 7 deve preceder Tarefa 8 e deverá ser feito pelo mesmo robô)

            var N8 = new State("N", Marking.Unmarked);
            var f7 = new State("f7", Marking.Unmarked);
            var ff7 = new State("f7'", Marking.Unmarked);
            var f7f8 = new State("7f.8f", Marking.Marked);

            var h8 = new HashSet<Transition>
            {
                new Transition(N8, a7s, N8),
                new Transition(N8, b7s, N8),
                new Transition(N8, a7f, f7),
                new Transition(N8, b7f, ff7),
                new Transition(f7, a8s, f7),
                new Transition(ff7, b8s, ff7),
                new Transition(f7, a8f, f7f8),
                new Transition(ff7, b8f, f7f8)
            };

            var E8 = new DeterministicFiniteAutomaton(h8, N8, "E8");
            //E8.ShowAutomaton("E8");

            // Especificação 9
            //(Tarefa 9 deve preceder Tarefa 10 e deverá ser feito pelo mesmo robô)

            var N9 = new State("N", Marking.Unmarked);
            var f9 = new State("f9", Marking.Unmarked);
            var ff9 = new State("f9'", Marking.Unmarked);
            var f9f10 = new State("9f.10f", Marking.Marked);

            var h9 = new HashSet<Transition>
            {
                new Transition(N9, a9s, N9),
                new Transition(N9, b9s, N9),
                new Transition(N9, a9f, f9),
                new Transition(N9, b9f, ff9),
                new Transition(f9, a10s, f9),
                new Transition(ff9, b10s, ff9),
                new Transition(f9, a10f, f9f10),
                new Transition(ff9, b10f, f9f10)
            };

            var E9 = new DeterministicFiniteAutomaton(h9, N9, "E9");
            //E9.ShowAutomaton("E9");


            DeterministicFiniteAutomaton s = DeterministicFiniteAutomaton.MonolithicSupervisor(new[] { GeoA, GeoB, TaskA, TaskB }, new[] { E1, E2, E3, E4, E5, E6, E7, E8, E9 });

            var q = s.States.ToArray();
            var e = s.Events.ToArray();

            var arq = new StreamWriter("events.txt");

            for(int i = 0; i < e.Length; i++)
            {
                arq.WriteLine("{0} {1} {2}", e[i].IsControllable ? i + 1 : -i - 1, e[i], e[i].Controllability);
            }

            arq.Close();

            var statesIndex = new Dictionary<AbstractState, int>();

            for (int i = 0; i < q.Length; i++)
                statesIndex.Add(q[i], i);

            arq = new StreamWriter("matrix.txt");
            foreach (var t in s.Transitions)
            {
                arq.WriteLine("{0} {1} {2}", statesIndex[t.Origin] + 1, statesIndex[t.Destination] + 1
                    , t.Trigger.IsControllable ? (Array.IndexOf(e, t.Trigger) + 1) : -(Array.IndexOf(e, t.Trigger) + 1));
            }

            arq.Close();

            return s;
        }

        private static void Marcio()
        {
            // creating States (0 to 5)
            State s0 = new State("s0", Marking.Marked);
            State s1 = new State("s1", Marking.Unmarked);
            State s2 = new State("s2", Marking.Unmarked);
            State s3 = new State("s3", Marking.Unmarked);
            State s4 = new State("s4", Marking.Unmarked);
            State s5 = new State("s5", Marking.Unmarked);
            // creating States (0,0;0,1...)
            State s00 = new State("s00", Marking.Marked);
            State s01 = new State("s01", Marking.Unmarked);
            State s02 = new State("s02", Marking.Unmarked);
            State s03 = new State("s03", Marking.Unmarked);
            State s10 = new State("s10", Marking.Unmarked);
            State s11 = new State("s11", Marking.Unmarked);
            State s12 = new State("s12", Marking.Unmarked);
            State s20 = new State("s20", Marking.Unmarked);
            State s21 = new State("s21", Marking.Unmarked);
            State s30 = new State("s30", Marking.Unmarked);
            // creating States (0,0,0;0,0,1...)
            State s000 = new State("s000", Marking.Marked);
            State s001 = new State("s001", Marking.Unmarked);
            State s002 = new State("s002", Marking.Unmarked);
            State s010 = new State("s010", Marking.Unmarked);
            State s011 = new State("s011", Marking.Unmarked);
            State s020 = new State("s020", Marking.Unmarked);
            State s100 = new State("s100", Marking.Unmarked);
            State s101 = new State("s101", Marking.Unmarked);
            State s110 = new State("s110", Marking.Unmarked);
            State s200 = new State("s200", Marking.Unmarked);

            // Creating Events
            Event e11a = new Event("e11a", Controllability.Controllable);
            Event e11b = new Event("e11b", Controllability.Controllable);
            Event e11c = new Event("e11c", Controllability.Controllable);
            Event e12a = new Event("e12a", Controllability.Uncontrollable);
            Event e12b = new Event("e12b", Controllability.Uncontrollable);
            Event e12c = new Event("e12c", Controllability.Uncontrollable);

            Event e21a = new Event("e21a", Controllability.Controllable);
            Event e21b = new Event("e21b", Controllability.Controllable);
            Event e21c = new Event("e21c", Controllability.Controllable);
            Event e22a = new Event("e22a", Controllability.Uncontrollable);
            Event e22b = new Event("e22b", Controllability.Uncontrollable);
            Event e22c = new Event("e22c", Controllability.Uncontrollable);

            Event e31 = new Event("e31", Controllability.Controllable);
            Event e32 = new Event("e32", Controllability.Uncontrollable);
            Event e33 = new Event("e33", Controllability.Controllable);
            Event e34 = new Event("e34", Controllability.Uncontrollable);
            Event e35 = new Event("e35", Controllability.Controllable);
            Event e36 = new Event("e36", Controllability.Uncontrollable);
            Event e37 = new Event("e37", Controllability.Controllable);
            Event e38 = new Event("e38", Controllability.Uncontrollable);
            Event e39 = new Event("e39", Controllability.Controllable);
            Event e30 = new Event("e30", Controllability.Uncontrollable);

            Event e41a = new Event("e41a", Controllability.Controllable);
            Event e41b = new Event("e41b", Controllability.Controllable);
            Event e41c = new Event("e41c", Controllability.Controllable);
            Event e42a = new Event("e42a", Controllability.Uncontrollable);
            Event e42b = new Event("e42b", Controllability.Uncontrollable);
            Event e42c = new Event("e42c", Controllability.Uncontrollable);

            Event e51a = new Event("e51a", Controllability.Controllable);
            Event e51b = new Event("e51b", Controllability.Controllable);
            Event e51c = new Event("e51c", Controllability.Controllable);
            Event e52a = new Event("e52a", Controllability.Uncontrollable);
            Event e52b = new Event("e52b", Controllability.Uncontrollable);
            Event e52c = new Event("e52c", Controllability.Uncontrollable);
            Event e53a = new Event("e53a", Controllability.Controllable);
            Event e53b = new Event("e53b", Controllability.Controllable);
            Event e53c = new Event("e53c", Controllability.Controllable);
            Event e54a = new Event("e54a", Controllability.Uncontrollable);
            Event e54b = new Event("e54b", Controllability.Uncontrollable);
            Event e54c = new Event("e54c", Controllability.Uncontrollable);

            Event e61a = new Event("e61a", Controllability.Controllable);
            Event e61b = new Event("e61b", Controllability.Controllable);
            Event e63a = new Event("e63a", Controllability.Controllable);
            Event e63b = new Event("e63b", Controllability.Controllable);
            Event e65a = new Event("e65a", Controllability.Controllable);
            Event e65b = new Event("e65b", Controllability.Controllable);

            Event e64a = new Event("e64a", Controllability.Uncontrollable);
            Event e64b = new Event("e64b", Controllability.Uncontrollable);
            Event e66a = new Event("e66a", Controllability.Uncontrollable);
            Event e66b = new Event("e66b", Controllability.Uncontrollable);

            Event e71a = new Event("e71a", Controllability.Controllable);
            Event e71b = new Event("e71b", Controllability.Controllable);
            Event e72a = new Event("e72a", Controllability.Uncontrollable);
            Event e72b = new Event("e72b", Controllability.Uncontrollable);
            Event e73a = new Event("e73a", Controllability.Controllable);
            Event e73b = new Event("e73b", Controllability.Controllable);
            Event e74a = new Event("e74a", Controllability.Uncontrollable);
            Event e74b = new Event("e74b", Controllability.Uncontrollable);
            Event e81a = new Event("e81a", Controllability.Controllable);
            Event e81b = new Event("e81b", Controllability.Controllable);
            Event e82a = new Event("e82a", Controllability.Uncontrollable);
            Event e82b = new Event("e82b", Controllability.Uncontrollable);

            //----------------------------
            // Plants
            //----------------------------


            // C1
            var C1a = new DeterministicFiniteAutomaton(
                new[]
                {
                    new Transition(s0, e11a, s1),
                    new Transition(s1, e12a, s0)
                },
                s0, "C1a");


            var C1b = new DeterministicFiniteAutomaton(
                new[]
                {
                    new Transition(s0, e11b, s1),
                    new Transition(s1, e12b, s0)
                },
                s0, "C1b");


            //var C1c = new DeterministicFiniteAutomaton(
            //    new[]
            //    {
            //        new Transition(s0, e11c, s1),
            //        new Transition(s1, e12c, s0)
            //    },
            //    s0, "C1c");


            // C2
            var C2a = new DeterministicFiniteAutomaton(
                new[]
                {
                    new Transition(s0, e21a, s1),
                    new Transition(s1, e22a, s0)
                },
                s0, "C2a");


            var C2b = new DeterministicFiniteAutomaton(
                new[]
                {
                    new Transition(s0, e21b, s1),
                    new Transition(s1, e22b, s0)
                },
                s0, "C2b");


            //var C2c = new DeterministicFiniteAutomaton(
            //    new[]
            //    {
            //        new Transition(s0, e21c, s1),
            //        new Transition(s1, e22c, s0)
            //    },
            //    s0, "C2c");


            // C3
            var C3a = new DeterministicFiniteAutomaton(
                new[]
                {
                    new Transition(s0, e71a, s1),
                    new Transition(s1, e72a, s0),
                    new Transition(s0, e73a, s2),
                    new Transition(s2, e74a, s0)
                },
                s0, "C3a");


            var C3b = new DeterministicFiniteAutomaton(
                new[]
                {
                    new Transition(s0, e71b, s1),
                    new Transition(s1, e72b, s0),
                    new Transition(s0, e73b, s2),
                    new Transition(s2, e74b, s0)
                },
                s0, "C3b");


            // MP - Maquina de pintura
            var MPa = new DeterministicFiniteAutomaton(
                new[]
                {
                    new Transition(s0, e81a, s1),
                    new Transition(s1, e82a, s0)
                },
                s0, "MPa");


            var MPb = new DeterministicFiniteAutomaton(
                new[]
                {
                    new Transition(s0, e81b, s1),
                    new Transition(s1, e82b, s0)
                },
                s0, "MPb");




            // MM - Máquina de Montar
            var MMa = new DeterministicFiniteAutomaton(
                 new[]
                 {
                    new Transition(s0, e61a, s1),
                    new Transition(s1, e63a, s2),
                    new Transition(s1, e65a, s3),
                    new Transition(s2, e64a, s0),
                    new Transition(s3, e66a, s0)
                 },
                 s0, "MMa");


            var MMb = new DeterministicFiniteAutomaton(
                new[]
                {
                    new Transition(s0, e61b, s1),
                    new Transition(s1, e63b, s2),
                    new Transition(s1, e65b, s3),
                    new Transition(s2, e64b, s0),
                    new Transition(s3, e66b, s0)
                },
                s0, "MMb");


            // Milling - Fresa
            var Fa = new DeterministicFiniteAutomaton(
                new[]
                {
                    new Transition(s0, e41a, s1),
                    new Transition(s1, e42a, s0)
                },
                s0, "Fa");


            var Fb = new DeterministicFiniteAutomaton(
               new[]
               {
                    new Transition(s0, e41b, s1),
                    new Transition(s1, e42b, s0)
               },
               s0, "Fb");


            //var Fc = new DeterministicFiniteAutomaton(
            //   new[]
            //   {
            //        new Transition(s0, e41c, s1),
            //        new Transition(s1, e42c, s0)
            //   },
            //   s0, "Fc");


            // Lathe - torno
            var Ta = new DeterministicFiniteAutomaton(
                new[]
                {
                    new Transition(s0, e53a, s1),
                    new Transition(s1, e54a, s0),
                    new Transition(s0, e51a, s2),
                    new Transition(s2, e52a, s0)
                },
                s0, "Ta");


            var Tb = new DeterministicFiniteAutomaton(
                new[]
                {
                    new Transition(s0, e53b, s1),
                    new Transition(s1, e54b, s0),
                    new Transition(s0, e51b, s2),
                    new Transition(s2, e52b, s0)
                },
                s0, "Tb");


            //var Tc = new DeterministicFiniteAutomaton(
            //    new[]
            //    {
            //        new Transition(s0, e53c, s1),
            //        new Transition(s1, e54c, s0),
            //        new Transition(s0, e51c, s2),
            //        new Transition(s2, e52c, s0)
            //    },
            //    s0, "Tc");


            // Robot
            var Robo = new DeterministicFiniteAutomaton(
                new[]
                {
                    new Transition(s0, e31, s1),
                    new Transition(s1, e32, s0),
                    new Transition(s0, e33, s2),
                    new Transition(s2, e34, s0),
                    new Transition(s0, e35, s3),
                    new Transition(s3, e36, s0),
                    new Transition(s0, e37, s4),
                    new Transition(s4, e38, s0),
                    new Transition(s0, e39, s5),
                    new Transition(s5, e30, s0)
                },
                s0, "Robo");

            //----------------------------
            // Specifications
            //----------------------------


            // E1
            var E1 = new DeterministicFiniteAutomaton(
                new[]
                {
                    new Transition(s0, e12a, s1),
                    new Transition(s0, e12b, s1),
                    new Transition(s1, e31, s0),
                    new Transition(s1, e12a, s2),
                    new Transition(s1, e12b, s2),
                    new Transition(s2, e31, s1)
                },
                s0, "E1");


            // E2
            var E2 = new DeterministicFiniteAutomaton(
                new[]
                {
                    new Transition(s0, e22a, s1),
                    new Transition(s0, e22b, s1),
                    new Transition(s1, e33, s0),
                    new Transition(s1, e22a, s2),
                    new Transition(s1, e22b, s2),
                    new Transition(s2, e33, s1)
                },
                s0, "E2");


            //E3 - Buffer B3
            var E3 = new DeterministicFiniteAutomaton(
                new[]
                {
                    new Transition(s00, e32, s10),
                    new Transition(s10, e41a, s00),
                    new Transition(s10, e41b, s00),
                    new Transition(s10, e32, s20),
                    new Transition(s20, e41a, s10),
                    new Transition(s20, e41b, s10),
                    new Transition(s00, e42a, s01),
                    new Transition(s00, e42b, s01),
                    new Transition(s01, e35, s00),
                    new Transition(s10, e42a, s11),
                    new Transition(s10, e42b, s11),
                    new Transition(s11, e35, s10),
                    new Transition(s01, e32, s11),
                    new Transition(s11, e41a, s01),
                    new Transition(s11, e41b, s01),
                    new Transition(s01, e42a, s02),
                    new Transition(s01, e42b, s02),
                    new Transition(s02, e35, s01)
                },
                s00, "E3");


            //E4- Buffer B4
            var E4 = new DeterministicFiniteAutomaton(
                new[]
                {
                    new Transition(s000, e34, s100),
                    new Transition(s100, e51a, s000),
                    new Transition(s100, e51b, s000),
                    new Transition(s100, e53a, s000),
                    new Transition(s100, e53b, s000),
                    new Transition(s100, e34, s200),
                    new Transition(s200, e51a, s100),
                    new Transition(s200, e51b, s100),
                    new Transition(s200, e53a, s100),
                    new Transition(s200, e53b, s100),
                    new Transition(s000, e52a, s010),
                    new Transition(s000, e52b, s010),
                    new Transition(s010, e37, s000),
                    new Transition(s100, e52a, s110),
                    new Transition(s100, e52b, s110),
                    new Transition(s110, e37, s100),
                    new Transition(s010, e34, s110),
                    new Transition(s110, e51a, s010),
                    new Transition(s110, e51b, s010),
                    new Transition(s110, e53a, s010),
                    new Transition(s110, e53b, s010),
                    new Transition(s010, e52a, s020),
                    new Transition(s010, e52b, s020),
                    new Transition(s020, e37, s010),
                    new Transition(s000, e54a, s001),
                    new Transition(s000, e54b, s001),
                    new Transition(s001, e39, s000),
                    new Transition(s100, e54a, s101),
                    new Transition(s100, e54b, s101),
                    new Transition(s101, e39, s100),
                    new Transition(s001, e34, s101),
                    new Transition(s101, e51a, s001),
                    new Transition(s101, e51b, s001),
                    new Transition(s101, e53a, s001),
                    new Transition(s101, e53b, s001),
                    new Transition(s001, e54a, s002),
                    new Transition(s001, e54b, s002),
                    new Transition(s002, e39, s001),
                    new Transition(s001, e52a, s011),
                    new Transition(s001, e52b, s011),
                    new Transition(s011, e37, s001),
                    new Transition(s010, e54a, s011),
                    new Transition(s010, e54b, s011),
                    new Transition(s011, e39, s010)
                },
                s000, "E4");


            // E5
            var E5 = new DeterministicFiniteAutomaton(
                new[]
                {
                    new Transition(s0, e36, s1),
                    new Transition(s1, e61a, s0),
                    new Transition(s1, e61b, s0),
                    new Transition(s1, e36, s2),
                    new Transition(s2, e61a, s1),
                    new Transition(s2, e61b, s1)
                },
                s0, "E5");


            // E6
            var E6 = new DeterministicFiniteAutomaton(
                new[]
                {
                    new Transition(s0, e38, s1),
                    new Transition(s1, e63a, s0),
                    new Transition(s1, e63b, s0),
                    new Transition(s1, e38, s2),
                    new Transition(s2, e63a, s1),
                    new Transition(s2, e63b, s1)
                },
                s0, "E6");


            // E7
            var E7 = new DeterministicFiniteAutomaton(
                new[]
                {
                    new Transition(s00, e30, s10),
                    new Transition(s10, e71a, s00),
                    new Transition(s10, e71b, s00),
                    new Transition(s10, e30, s20),
                    new Transition(s20, e71a, s10),
                    new Transition(s20, e71b, s10),
                    new Transition(s00, e74a, s01),
                    new Transition(s00, e74b, s01),
                    new Transition(s01, e65a, s00),
                    new Transition(s01, e65b, s00),
                    new Transition(s10, e74a, s11),
                    new Transition(s10, e74b, s11),
                    new Transition(s11, e65a, s10),
                    new Transition(s11, e65b, s10),
                    new Transition(s01, e30, s11),
                    new Transition(s11, e71a, s01),
                    new Transition(s11, e71b, s01),
                    new Transition(s01, e74a, s02),
                    new Transition(s01, e74b, s02),
                    new Transition(s02, e65a, s01),
                    new Transition(s02, e65b, s01)
                },
                s00, "E7");


            // E8
            var E8 = new DeterministicFiniteAutomaton(
                new[]
                {
                    new Transition(s00, e72a, s10),
                    new Transition(s00, e72b, s10),
                    new Transition(s10, e81a, s00),
                    new Transition(s10, e81b, s00),
                    new Transition(s10, e72a, s20),
                    new Transition(s10, e72b, s20),
                    new Transition(s20, e81a, s10),
                    new Transition(s20, e81b, s10),
                    new Transition(s00, e82a, s01),
                    new Transition(s00, e82b, s01),
                    new Transition(s01, e73a, s00),
                    new Transition(s01, e73b, s00),
                    new Transition(s10, e82a, s11),
                    new Transition(s10, e82b, s11),
                    new Transition(s11, e73a, s10),
                    new Transition(s11, e73b, s10),
                    new Transition(s01, e72a, s11),
                    new Transition(s01, e72b, s11),
                    new Transition(s11, e81a, s01),
                    new Transition(s11, e81b, s01),
                    new Transition(s01, e82a, s02),
                    new Transition(s01, e82b, s02),
                    new Transition(s02, e73a, s01),
                    new Transition(s02, e73b, s01)
                },
                s00, "E8");


            // Computing the confict solving supervisor 
            var E78 = E7.ParallelCompositionWith(E8);


            //cria lista plantas e especificações geral
            List<DeterministicFiniteAutomaton> plants;
            List<DeterministicFiniteAutomaton> specs;


            plants = new[] { C1a, C1b, C2a, C2b, Fa, Fb, Ta, Tb, Robo, MMa, MMb, C3a, C3b, MPa, MPb }.ToList();
            specs = new[] { E1, E2, E3, E4, E5, E6, E7, E8, E78 }.ToList();
            Console.WriteLine("teste: {0}", E78.States.Count());
            DeterministicFiniteAutomaton.ToWmodFile("marcio.wmod", plants, specs);

            return;
            //cria lista plantas e especificações (MAXIMO QUE RODOU COMPUTADOR MARCIO NUNES)
            //plants = new[] { C1a, C1b, C2a, C2b, Robo, Fa, Fb, Ta, Tb, MMa, MMb}.ToList();
            //specs = new[] { E1, E2, E3, E4, E5, E6}.ToList();


            //cria plantas locais atraves da composição dos autômatos que possuem eventos em comum nas especificações


            //var G1a = C1a.ParallelCompositionWith(C1b);
            //var G1var = G1a.ParallelCompositionWith(Robo);
            //List<DeterministicFiniteAutomaton> G1;
            //G1 = new[] { G1var }.ToList();


            //var G2a = C2a.ParallelCompositionWith(C2b);
            //var G2var = G2a.ParallelCompositionWith(Robo);
            //List<DeterministicFiniteAutomaton> G2;
            //G2 = new[] { G2var }.ToList();


            //var G3a = Fa.ParallelCompositionWith(Fb);
            //var G3var = G3a.ParallelCompositionWith(Robo);
            //List<DeterministicFiniteAutomaton> G3;
            //G3 = new[] { G3var }.ToList();


            //var G4a = Ta.ParallelCompositionWith(Tb);
            //var G4var = G4a.ParallelCompositionWith(Robo);
            //List<DeterministicFiniteAutomaton> G4;
            //G4 = new[] { G4var }.ToList();


            //var G5a = MMa.ParallelCompositionWith(MMb);
            //var G5var = G5a.ParallelCompositionWith(Robo);
            //List<DeterministicFiniteAutomaton> G5;
            //G5 = new[] { G5var }.ToList();


            //var G78a = C3a.ParallelCompositionWith(C3b);
            //var G78b = G78a.ParallelCompositionWith(Robo);
            //var G78c = G78b.ParallelCompositionWith(MPa);
            //var G78var = G78c.ParallelCompositionWith(MPb);
            //List<DeterministicFiniteAutomaton> G78;
            //G78 = new[] { G78var }.ToList();




            //cria linguagens K atraves da composição dos das plantas locais Gi com as especificações Ei


            //var K1var = G1var.ParallelCompositionWith(E1);
            //List<DeterministicFiniteAutomaton> K1;
            //K1 = new[] { K1var }.ToList();


            //var K2var = G2var.ParallelCompositionWith(E2);
            //List<DeterministicFiniteAutomaton> K2;
            //K2 = new[] { K2var }.ToList();


            //var K3var = G3var.ParallelCompositionWith(E3);
            //List<DeterministicFiniteAutomaton> K3;
            //K3 = new[] { K3var }.ToList();


            //var K4var = G4var.ParallelCompositionWith(E4);
            //List<DeterministicFiniteAutomaton> K4;
            //K4 = new[] { K4var }.ToList();


            //var K5var = G5var.ParallelCompositionWith(E5);
            //List<DeterministicFiniteAutomaton> K5;
            //K5 = new[] { K5var }.ToList();


            //var K6var = G5var.ParallelCompositionWith(E6);
            //List<DeterministicFiniteAutomaton> K6;
            //K6 = new[] { K6var }.ToList();


            //var K78a = E7.ParallelCompositionWith(E8);
            //var K78var = K78a.ParallelCompositionWith(G78var);
            //List<DeterministicFiniteAutomaton> K78;
            //K78 = new[] { K78var }.ToList();



            // Cálculo do supervisor monolítico
            var timer = new Stopwatch();
            timer.Start();
            var sup = DeterministicFiniteAutomaton.MonolithicSupervisor(plants, specs);


            // Cálculo de cada supervisor modular local
            //var sup1 = DeterministicFiniteAutomaton.MonolithicSupervisor(G1, K1, true);
            //var sup2 = DeterministicFiniteAutomaton.MonolithicSupervisor(G2, K2, true);
            //var sup3 = DeterministicFiniteAutomaton.MonolithicSupervisor(G3, K3, true);
            //var sup4 = DeterministicFiniteAutomaton.MonolithicSupervisor(G4, K4, true);
            //var sup5 = DeterministicFiniteAutomaton.MonolithicSupervisor(G5, K5, true);
            //var sup6 = DeterministicFiniteAutomaton.MonolithicSupervisor(G5, K6, true);
            //var sup78 = DeterministicFiniteAutomaton.MonolithicSupervisor(G78, K78, true);


            timer.Stop();


            // Calculo da composição dos supervisores modulares locais
            //var compa = sup1.ParallelCompositionWith(sup2);
            //var compb = compa.ParallelCompositionWith(sup3);
            //var compc = compb.ParallelCompositionWith(sup4);
            //var compd = compc.ParallelCompositionWith(sup5);
            //var compe = compd.ParallelCompositionWith(sup6);
            //var comp = compe.ParallelCompositionWith(sup78);


            // Calculo da componente TRIM da composição dos supervisores modulares locais
            //var trimcomp = comp.Trim;

            //Grava cada supervisor modular local
            //sup1.ToXMLFile("sup1.xml");
            //sup2.ToXMLFile("sup2.xml");
            //sup3.ToXMLFile("sup3.xml");
            //sup4.ToXMLFile("sup4.xml");
            //sup5.ToXMLFile("sup5.xml");
            //sup6.ToXMLFile("sup6.xml");
            //sup78.ToXMLFile("sup78.xml");


            // Calculo da componente TRIM do supervisor monolítico
            var trimsup = sup.Trim;

            //Mostra tempo de computação, numero de estados e numero de transições do supervisor monolítico e sua componente TRIM
            Console.WriteLine("Computation Time: {0}", timer.ElapsedMilliseconds / 1000.0);
            Console.WriteLine("size: {0}", sup.size);
            Console.WriteLine("size TRIM: {0}", trimsup.size);
            Console.WriteLine("Transitions: {0}", sup.Transitions.Count());


            //Mostra numero de estados e numero de transições da composição dos supervisores modulares locais e sua componente TRIM
            //Console.WriteLine("size composition: {0}", comp.size);
            //Console.WriteLine("size composition trim: {0}", trimcomp.size);
            //Console.WriteLine("Transitions composition: {0}", comp.Transitions.Count());
            //Console.WriteLine("Transitions composition trim: {0}", trimcomp.Transitions.Count());
        }

        private static void ITL(out List<DeterministicFiniteAutomaton> plants, out List<DeterministicFiniteAutomaton> specs)
        {
            var s = Enumerable.Range(0, 3).Select( i =>
                    new State(i.ToString(), i < 2 ? Marking.Marked : Marking.Unmarked)
                ).ToArray();

            plants = new List<DeterministicFiniteAutomaton>();
            specs = new List<DeterministicFiniteAutomaton>();

            var evs = Enumerable.Range(0, 12).Select(i => new Event(
                String.Format(i % 2 == 0 ? "a{0}" : "b{0}", 1 + (int)(i / 2)),
                    i % 2 == 0
                        ? Controllability.Controllable
                        : Controllability.Uncontrollable)).ToArray();

            var Gs = new DeterministicFiniteAutomaton[6];
            for (var i = 0; i < 6; i++)
            {
                Gs[i] = new DeterministicFiniteAutomaton(new[]
                {
                    new Transition(s[0], evs[2*i], s[2]),
                    new Transition(s[2], evs[2*i + 1], s[0])
                }, s[0], String.Format("M{0}", i + 1));
            }

            for(var i = 0; i < 5; i += 2)
            {
                var E = new DeterministicFiniteAutomaton(new[]
                {
                    new Transition(s[0], evs[2*i + 1], s[1]),
                    new Transition(s[1], evs[2*i + 2], s[0])
                }, s[0], String.Format("E{0}", i + 1));

                specs.Add(E);
                plants.Add(Gs[i].ParallelCompositionWith(Gs[i + 1]));
            }
            var Ec = new DeterministicFiniteAutomaton(new[]
            {
                new Transition(s[0], evs[3], s[1]),
                new Transition(s[0], evs[7], s[1]),
                new Transition(s[1], evs[8], s[0])
            }, s[0], String.Format("Ec"));

            specs.Add(Ec);

            plants.Add(plants.Last().ParallelCompositionWith(Gs[1], false));
        }

        private static void Main()
        {
            /*Marcio();
            Console.ReadLine();
            return;
            */
            // creating States (0 to 6)
            
            var s =
                Enumerable.Range(0, 6)
                    .Select(i =>
                        new State(i.ToString(),
                            i == 0
                                ? Marking.Marked
                                : Marking.Unmarked)
                    ).ToArray();

            // Creating Events (0 to 100)
            var e =
                Enumerable.Range(0, 100)
                    .Select(i =>
                        new Event(i.ToString(),
                            i % 2 != 0
                                ? Controllability.Controllable
                                : Controllability.Uncontrollable)
                    ).ToArray();

            //----------------------------
            // Plants
            //----------------------------

            // C1
            var c1 = new DeterministicFiniteAutomaton(
                new[]
                {
                    new Transition(s[0], e[11], s[1]),
                    new Transition(s[1], e[12], s[0])
                },
                s[0], "C1");

            // C2
            var c2 = new DeterministicFiniteAutomaton(
                new[]
                {
                    new Transition(s[0], e[21], s[1]),
                    new Transition(s[1], e[22], s[0])
                },
                s[0], "C2");

            // Milling
            var milling = new DeterministicFiniteAutomaton(
                new[]
                {
                    new Transition(s[0], e[41], s[1]),
                    new Transition(s[1], e[42], s[0])
                },
                s[0], "Milling");

            // MP
            var mp = new DeterministicFiniteAutomaton(
                new[]
                {
                    new Transition(s[0], e[81], s[1]),
                    new Transition(s[1], e[82], s[0])
                },
                s[0], "MP");

            // Lathe
            var lathe = new DeterministicFiniteAutomaton(
                new[]
                {
                    new Transition(s[0], e[51], s[1]),
                    new Transition(s[1], e[52], s[0]),
                    new Transition(s[0], e[53], s[2]),
                    new Transition(s[2], e[54], s[0])
                },
                s[0], "Lathe");

            // C3
            var c3 = new DeterministicFiniteAutomaton(
                new[]
                {
                    new Transition(s[0], e[71], s[1]),
                    new Transition(s[1], e[72], s[0]),
                    new Transition(s[0], e[73], s[2]),
                    new Transition(s[2], e[74], s[0])
                },
                s[0], "C3");

            // Robot
            var robot = new DeterministicFiniteAutomaton(
                new[]
                {
                    new Transition(s[0], e[31], s[1]),
                    new Transition(s[1], e[32], s[0]),
                    new Transition(s[0], e[33], s[2]),
                    new Transition(s[2], e[34], s[0]),
                    new Transition(s[0], e[35], s[3]),
                    new Transition(s[3], e[36], s[0]),
                    new Transition(s[0], e[37], s[4]),
                    new Transition(s[4], e[38], s[0]),
                    new Transition(s[0], e[39], s[5]),
                    new Transition(s[5], e[30], s[0])
                },
                s[0], "Robot");

            // MM
            var mm = new DeterministicFiniteAutomaton(
                new[]
                {
                    new Transition(s[0], e[61], s[1]),
                    new Transition(s[1], e[63], s[2]),
                    new Transition(s[1], e[65], s[3]),
                    new Transition(s[2], e[64], s[0]),
                    new Transition(s[3], e[66], s[0])
                },
                s[0], "MM");

            //----------------------------
            // Specifications
            //----------------------------

            // E1
            var e1 = new DeterministicFiniteAutomaton(
                new[]
                {
                    new Transition(s[0], e[12], s[1]),
                    new Transition(s[1], e[31], s[0])
                },
                s[0], "E1");

            // E2
            var e2 = new DeterministicFiniteAutomaton(
                new[]
                {
                    new Transition(s[0], e[22], s[1]),
                    new Transition(s[1], e[33], s[0])
                },
                s[0], "E2");

            // E5
            var e5 = new DeterministicFiniteAutomaton(
                new[]
                {
                    new Transition(s[0], e[36], s[1]),
                    new Transition(s[1], e[61], s[0])
                },
                s[0], "E5");

            // E6
            var e6 = new DeterministicFiniteAutomaton(
                new[]
                {
                    new Transition(s[0], e[38], s[1]),
                    new Transition(s[1], e[63], s[0])
                },
                s[0], "E6");

            // E3
            var e3 = new DeterministicFiniteAutomaton(
                new[]
                {
                    new Transition(s[0], e[32], s[1]),
                    new Transition(s[1], e[41], s[0]),
                    new Transition(s[0], e[42], s[2]),
                    new Transition(s[2], e[35], s[0])
                },
                s[0], "E3");

            // E7
            var e7 = new DeterministicFiniteAutomaton(
                new[]
                {
                    new Transition(s[0], e[30], s[1]),
                    new Transition(s[1], e[71], s[0]),
                    new Transition(s[0], e[74], s[2]),
                    new Transition(s[2], e[65], s[0])
                },
                s[0], "E7");

            // E8
            var e8 = new DeterministicFiniteAutomaton(
                new[]
                {
                    new Transition(s[0], e[72], s[1]),
                    new Transition(s[1], e[81], s[0]),
                    new Transition(s[0], e[82], s[2]),
                    new Transition(s[2], e[73], s[0])
                },
                s[0], "E8");

            // E4
            var e4 = new DeterministicFiniteAutomaton(
                new[]
                {
                    new Transition(s[0], e[34], s[1]),
                    new Transition(s[1], e[51], s[0]),
                    new Transition(s[1], e[53], s[0]),
                    new Transition(s[0], e[52], s[2]),
                    new Transition(s[2], e[37], s[0]),
                    new Transition(s[0], e[54], s[3]),
                    new Transition(s[3], e[39], s[0])
                },
                s[0], "E4");

            var e78 = e7.ParallelCompositionWith(e8);

            List<DeterministicFiniteAutomaton> plants;
            List<DeterministicFiniteAutomaton> specs;

            plants = new[] { c1, c2, milling, lathe, robot, mm, c3, mp }.ToList();
            specs = new[] { e1, e2, e3, e4, e5, e6, e7, e8 }.ToList();
            //ClusterTool(5, out plants, out specs);
            //DeterministicFiniteAutomaton.FromWmodFile("RAC.wmod", out plants, out specs);

            var timer = new Stopwatch();
            timer.Start();

            var sup = DeterministicFiniteAutomaton.MonolithicSupervisor(plants, specs, true);
            //var sup = Carol();
            timer.Stop();

            Console.WriteLine("Computation Time: {0}", timer.ElapsedMilliseconds / 1000.0);
            Console.WriteLine("size: {0}", sup.size);
            timer.Restart();
            Console.WriteLine("Transitions: {0}", sup.Transitions.Count());
            timer.Stop();
            Console.WriteLine("Computation Time: {0}", timer.ElapsedMilliseconds / 1000.0);

            Console.ReadLine();
        }
    }
}